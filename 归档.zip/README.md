# hsun0915_9103_tut10
My first repository for IDEA9103

This is my first local change to the repo!

# Header 1
## Header 2
### Header 3
#### Header 4
##### Header 5
###### Header 6

**Bold Text** or __Bold Text__
*Italic Text* or _Italic Text_

- Item 1
- Item 2
  - Subitem 2.1
  - Subitem 2.2

1. First Item
2. Second Item
3. Third Item

[Link Text](https://www.google.com)

![An image of a cat](http://placekitten.com/200/300)

![An image of the Mona Lisa](readmeImages/Mona_Lisa_by_Leonardo_da_Vinci_500_x_700.jpg)

```
function helloWorld() {
console.log("Hello, world!");
}
```

> This is a blockquote.